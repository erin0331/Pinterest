package bean;

public class CategoryDTO {
	private int cNo;
	private String title;
	private String cImg;
	public int getcNo() {
		return cNo;
	}
	public void setcNo(int cNo) {
		this.cNo = cNo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getcImg() {
		return cImg;
	}
	public void setcImg(String cImg) {
		this.cImg = cImg;
	}
	@Override
	public String toString() {
		return "CategoryDTO [cNo=" + cNo + ", title=" + title + ", cImg=" + cImg + "]";
	}
	
}
