package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.json.simple.JSONObject;

public class PinDAO {
	Connection con;
	DBConnectionMgr mgr;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public PinDAO() {
		mgr = DBConnectionMgr.getInstance();

	}
	
	public ArrayList<PinDTO> selectAll(String id) {
		ArrayList<PinDTO> list = new ArrayList<>();
		try {
			con = mgr.getConnection();
			
			String sql = "select p.iNo , i.imgUrl  from pin p inner join image i on p.iNo = i.iNo \r\n" + 
					"where p.id= ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				PinDTO dto = new PinDTO();
				dto.setiNo(rs.getInt(1));
				dto.setImgUrl(rs.getString(2));
				
				list.add(dto);
				
			}
			System.out.println("selectAll 마이핀 성공!");
			mgr.freeConnection(con, ps, rs);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	public int delete(PinDTO dto) {
		int result = 0;
		try {

			con = mgr.getConnection();
			
			String sql = "delete from pin where id = ? and iNo = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setInt(2, dto.getiNo());
			result = ps.executeUpdate();
			
			System.out.println("delete 핀해제 성공!");
			
			mgr.freeConnection(con, ps);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public ArrayList<PinDTO> makeMail(String id) {
		ArrayList<PinDTO> list = new ArrayList<>();
		try {
			con = mgr.getConnection();
			
			String sql = "select a.iNo,a.imgUrl \r\n" + 
					"from image a inner join (\r\n" + 
					"select * from pin where id = ?) b \r\n" + 
					"on a.cNo = b.cNo and a.iNo <>b.iNo \r\n" + 
					"order by rand() limit 20 ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				PinDTO dto = new PinDTO();
				dto.setiNo(rs.getInt(1));
				dto.setImgUrl(rs.getString(2));
				
				list.add(dto);
				
			}
			System.out.println("selectAll 마이핀 성공!");
			mgr.freeConnection(con, ps, rs);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
	//로그인 시 닉네임 불러오기 -> 상도씨 소스에서 활용
	public String getNick(String id) {

		String nickName = "";
		try {
			con = mgr.getConnection();
			
			String sql = "select nickName from member where id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			rs.next();
			
			nickName = rs.getString("nickName");
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			mgr.freeConnection(con);
		}
		return nickName;			
	}				
	
	//-----------이하 상도씨거
	//회원가입
		public boolean addMember(MemberDTO dto) {

			try {
				con = mgr.getConnection();
				
				String sql = "insert into member(id, pw, nickName) values(?,?,?)";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, dto.getId());
				pstmt.setString(2, dto.getPw());
				pstmt.setString(3, dto.getNickName());
				pstmt.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			finally {
				mgr.freeConnection(con);
			}
			return true;
	}
		
		//로그인
		public boolean login(String id, String pw) {
		
			boolean result = false;
			System.out.println(id);
			System.out.println(pw);	
			try {
				con = mgr.getConnection();
				
				String sql = "select id, pw from member where id = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, id);
				rs = pstmt.executeQuery();
				rs.next();
				System.out.println("디비쪽 아이디" +rs.getString("id"));
				System.out.println("디비쪽 비번" + rs.getString("pw"));
				if(rs.getString("pw").equals(pw))
					result=true;
			}catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			finally {
				mgr.freeConnection(con);
			}
			return result;			
		}	
		
		//관심사 불러오기
		public ArrayList<InterestDTO> inSelect(String id){
			InterestDTO dto2 = null;
			ArrayList<InterestDTO> list = new ArrayList<>();
			try {
			
				con = mgr.getConnection();
				String sql = "select id, cNo from interest where id = ? "; 
		
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, id);
				
				rs = pstmt.executeQuery();
				while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
					dto2 = new InterestDTO();
					System.out.println("검색 결과가 있어요.!!");
					String inId = rs.getString(1);
					int cNo = rs.getInt(2);
					System.out.println(inId);
					System.out.println(cNo);
					
					dto2.setId(inId);
					dto2.setcNo(cNo);
					list.add(dto2);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				mgr.freeConnection(con);
			}
			return list;
			
		}
		
		//타이틀 불러오기
		public ArrayList<String> titleSelect(ArrayList<ImageDTO> dto){
			ArrayList<String> list = new ArrayList<>();
			System.out.println("dto 사이즈: " + dto.size());
			try {
				con = mgr.getConnection();
				for (int i = 0; i < dto.size(); i++) {
								
				String sql = "select title from category where cNo = ? "; 
		
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, dto.get(i).getcNo());
				
				rs = pstmt.executeQuery();
				while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
					System.out.println("검색 결과가 있어요.!!");
					String title = rs.getString(1);				
					list.add(title);
					
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				mgr.freeConnection(con);
			}
			return list;
			
		}
		
		//title로 cNo불러오기
			public int cnoSelect(String search){
				int num = 0;
				try {
					con = mgr.getConnection();
									
					String sql = "select cNo from category where title = ? "; 
			
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, search);
					
					rs = pstmt.executeQuery();
					if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
						int cNo = rs.getInt(1);				
						num = cNo;
						
						}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					mgr.freeConnection(con);
				}
				return num;
				
			}
			
			
		//검색용 타이틀값 가지고오기
			public ArrayList<String> titleSelect(){
				ArrayList<String> list = new ArrayList<>();
				
				try {
					con = mgr.getConnection();
								
					String sql = "select title from category"; 
			
					pstmt = con.prepareStatement(sql);	
					rs = pstmt.executeQuery();
					while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
						String title = rs.getString(1);				
						list.add(title);
					}
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					mgr.freeConnection(con);
				}
				return list;
				
			}

			//JSON 형태로 변경
			public	JSONObject titleSelect3(){
				ArrayList<String> list = new ArrayList<>();
				JSONObject data = new JSONObject();
				
				int i=0;
				try {
					con = mgr.getConnection();
								
					String sql = "select title from category"; 
			
					pstmt = con.prepareStatement(sql);	
					rs = pstmt.executeQuery();
					while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
						String title = rs.getString(1);	
						System.out.println(title);
						list.add(title);
						data.put("title" + i, title);				
						i++;
				
					}
				
					
					String obj = data.toString();
					System.out.println(obj);
				
				} catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					mgr.freeConnection(con);
				}
				return data;
				
			}
		

		
		//메인 이미지	
		public ArrayList<ImageDTO> mainList(ArrayList<InterestDTO> dto) {
			ImageDTO dto2 = null;
			ArrayList<ImageDTO> list = new ArrayList<>();
		
		
			try {
			
				con = mgr.getConnection();
				for(int i=0; i < 5; i ++) {
		
					String sql = "select imgUrl from image where cNo = ? ORDER BY RAND() LIMIT 30"; 
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, dto.get(i).getcNo());
					rs = pstmt.executeQuery();
					while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
		
						String url = rs.getString(1);
						dto2 = new ImageDTO();
						dto2.setcNo(dto.get(i).getcNo());
						dto2.setImgUrl(url);
						list.add(dto2);
						}
					}
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				mgr.freeConnection(con);
			}
			return list;
	}	
		public int insert(PinDTO dto) {
		      int result = 0;
		      try {

		         con = mgr.getConnection();
		         
		         String sql = "insert into  pin values ( ?, ?, ? )";
		         PreparedStatement ps = con.prepareStatement(sql);
		         ps.setString(1, dto.getId());
		         ps.setInt(2, dto.getiNo());
		         ps.setInt(3, dto.getcNo());
		         result = ps.executeUpdate();
		         
		         System.out.println("핀등록 성공!");
		         
		         mgr.freeConnection(con, ps);

		      } catch (Exception e) {
		         // TODO Auto-generated catch block
		         e.printStackTrace();
		      }
		      return result;
		   }
		
		//검색 이미지	
			public ArrayList<ImageDTO> searchList(int searchNum) {
				ImageDTO dto2 = null;
				ArrayList<ImageDTO> list = new ArrayList<>();
			
				try {
				
					con = mgr.getConnection();
			
						String sql = "select imgUrl from image where cNo = ? ORDER BY RAND() LIMIT 100"; 
						pstmt = con.prepareStatement(sql);
						pstmt.setInt(1, searchNum);
						rs = pstmt.executeQuery();
						while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
							System.out.println("검색 결과가 있어요.!!");
							String url = rs.getString(1);
							dto2 = new ImageDTO();
							dto2.setcNo(searchNum);
							dto2.setImgUrl(url);
							list.add(dto2);			
						}
				} catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					mgr.freeConnection(con);
				}
				return list;
		}	

		
		//타이틀 불러오기
			public ArrayList<CategoryDTO> searchSelect(String search){
				CategoryDTO dto2 = null;
				ArrayList<CategoryDTO> list = new ArrayList<>();
			
				try {
					con = mgr.getConnection();
												
					String sql = "select cNo from category where title = ? "; 
			
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, search);
					
					rs = pstmt.executeQuery();
					while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
						dto2 = new CategoryDTO();
						int no = rs.getInt(1);		
						dto2.setcNo(no);				
						}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					mgr.freeConnection(con);
				}
				return list;
				
			}		
//---------------------주엽씨거
			
			//댓글 불러오기	
			public ArrayList<CommentDTO> commentList(int iNo) {
				CommentDTO dto2 = null;
				ArrayList<CommentDTO> list = new ArrayList<>();
			
				try {
					con = mgr.getConnection();
			
					String sql = "select * from comment where iNo = ?"; 
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, iNo);
					System.out.println("여기까지 실행됨 , 이미지 번호" + iNo);
					rs = pstmt.executeQuery();
					
					while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
						int iNo2 = rs.getInt(1);
						String nickname = rs.getString(2);
						String comment = rs.getString(3);
						String date = rs.getString(4);
						dto2 = new CommentDTO();
						dto2.setiNo(iNo2);
						dto2.setNickName(nickname);;
						dto2.setComment(comment);
						dto2.setDate(date);
						System.out.println("검색된 게시물 내용은 " + dto2);
						list.add(dto2);
						}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					mgr.freeConnection(con);
				}
				return list;
			}
			
			//More like this 불러오기	
			public ArrayList<ImageDTO> more(String imgUrl) {
				ImageDTO dto2 = null; //아직 객체 생성 안됨
				ArrayList<ImageDTO> list = new ArrayList<>();
				int iNo = 0;
				int cNo = 0;
				String imgUrl2 = null;
				try {
					con = mgr.getConnection();
					
					String sql = "select cNo from image where imgUrl = ?"; 
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, imgUrl);
					System.out.println("여기까지 실행됨 " + imgUrl);
					rs = pstmt.executeQuery();
					while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
						cNo = rs.getInt(1);
						System.out.println("카테고리 번호는 " + cNo);
					}
					
					String sql2 = "select * from image where cNo = ? ORDER BY RAND() LIMIT 10"; 
					pstmt = con.prepareStatement(sql2);
					pstmt.setInt(1, cNo);
					System.out.println("여기까지 실행됨 " + cNo);
					rs = pstmt.executeQuery();
					while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
						iNo = rs.getInt(1);
						cNo = rs.getInt(2);
						imgUrl2 = rs.getString(3);
						System.out.println("이미지 주소는 " + imgUrl);
						dto2 = new ImageDTO(); //여기서 객체 생성
						dto2.setiNo(iNo);
						dto2.setcNo(cNo);
						dto2.setImgUrl(imgUrl2);
						System.out.println(dto2);
						list.add(dto2);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					mgr.freeConnection(con);
				}
				return list;
			}	
			
				
			public ImageDTO select(String imgUrl) { //1개 사진 정보 불러오기 select
				
				ImageDTO dto = null; // try를 벗어나면 무용지물이라 밖에 만들어줌. 주소값으로서의 MemberDTO dto2. 아직 선언을 안해서 그저 클래스, 변수명 이름일 뿐. null.
				try {
					con = mgr.getConnection();
					//3) sql문 결정
					
					String sql = "select * from image where imgUrl = ?";
					PreparedStatement ps = con.prepareStatement(sql);
					ps.setString(1, imgUrl);
					System.out.println("3. sql문 결정 ok..");
					
					//4) sql문 전송
					ResultSet rs = ps.executeQuery(); 
					System.out.println("4. sql문 전송 ok..");
					
					if(rs.next()) { //검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
						dto = new ImageDTO();
						int iNo = rs.getInt(1);
						int cNo  = rs.getInt(2);
						String ImgUrl = rs.getString(3);
						dto.setiNo(iNo);
						dto.setcNo(cNo);
						dto.setImgUrl(ImgUrl);
					}
					mgr.freeConnection(con, ps);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return dto;
			}
			
			public MemberDTO selectMember(String email) { //로그인 회원정보 불러오기
				
				MemberDTO dto = null; // try를 벗어나면 무용지물이라 밖에 만들어줌. 주소값으로서의 MemberDTO dto2. 아직 선언을 안해서 그저 클래스, 변수명 이름일 뿐. null.
				try {
					con = mgr.getConnection();
					//3) sql문 결정
					
					String sql = "select id, nickName from member where id = ?";
					PreparedStatement ps = con.prepareStatement(sql);
					ps.setString(1, email);
					System.out.println("3. sql문 결정 ok..");
					
					//4) sql문 전송
					ResultSet rs = ps.executeQuery(); 
					System.out.println("4. sql문 전송 ok..");
					
					if(rs.next()) { //검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
						dto = new MemberDTO();
						String id = rs.getString(1);
						String nickName = rs.getString(2);
						dto.setId(id);
						dto.setNickName(nickName);
					}
					mgr.freeConnection(con, ps);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return dto;
			}
			
			//코멘트 추가
			public void addComment(CommentDTO dto) {

				try {
					con = mgr.getConnection();
					//3) sql문 결정
					String sql = "insert into comment (iNo, nickName, comment, date) values (?, ?, ?, ?)";
					pstmt = con.prepareStatement(sql);
					
					pstmt.setInt(1, dto.getiNo());
					pstmt.setString(2, dto.getNickName());
					pstmt.setString(3, dto.getComment());
					pstmt.setString(4, dto.getDate());
					System.out.println("3. sql문 결정 ok..");
					
					//4) sql문 전송
					pstmt.executeUpdate();
					
				}catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					mgr.freeConnection(con);
				}
				System.out.println("코멘트 추가 완료");
			}
			//영화 불러오기
			public ArrayList<MovieDTO> movieSelect(){
				MovieDTO dto2 = null;
				ArrayList<MovieDTO> list = new ArrayList<>();
			
				try {
					con = mgr.getConnection();
												
					String sql = "select title from movie"; 
			
					pstmt = con.prepareStatement(sql);				
					rs = pstmt.executeQuery();
					while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
						System.out.println("검색 결과가 있어요.!!");
						dto2 = new MovieDTO();
						String title = rs.getString(1);		
						dto2.setTitle(title);
						list.add(dto2);
						}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					mgr.freeConnection(con);
				}
				return list;
				
			}	

			
}




