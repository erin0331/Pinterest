package bean;

public class InterestDTO {
	private String id;
	private int cNo;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getcNo() {
		return cNo;
	}
	public void setcNo(int cNo) {
		this.cNo = cNo;
	}
	@Override
	public String toString() {
		return "InterestDTO [id=" + id + ", cNo=" + cNo + "]";
	}
	
}
