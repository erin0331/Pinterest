package bean;

public class PinDTO {
	private String id;
	private int iNo;
	private int cNo;
	private String imgUrl;
	
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getiNo() {
		return iNo;
	}
	public void setiNo(int iNo) {
		this.iNo = iNo;
	}
	public int getcNo() {
		return cNo;
	}
	public void setcNo(int cNo) {
		this.cNo = cNo;
	}
	@Override
	public String toString() {
		return "PinDTO [id=" + id + ", iNo=" + iNo + ", cNo=" + cNo + ", imgUrl=" + imgUrl + "]";
	}
	
}
