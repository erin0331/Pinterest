package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class InterestDAO {
	Connection con;
	DBConnectionMgr mgr;

	public InterestDAO() {
		mgr = DBConnectionMgr.getInstance();

	}

	public ArrayList<Integer> selectAll(String id) {
		ArrayList<Integer> list = new ArrayList();
		try {

			con = mgr.getConnection();

			String sql = "select cNo from interest where id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				list.add(rs.getInt(1));

			}
	//		System.out.println("---" + list.indexOf(1)); //값이 있으면 0 반환, 없으면 1반환
			System.out.println("selectAll 관심사list 성공!");

			/*
			 * for (int i = 0; i < list.size(); i++) { System.out.println("i "+list.get(i) +
			 * "//여부 : "+list.indexOf(list.get(i)) ); }
			 */
			
			mgr.freeConnection(con, ps, rs);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}
	
	public int delete(InterestDTO dto) {
		int result = 0;
		try {

			con = mgr.getConnection();
			System.out.println("id : "+dto.getId());
			System.out.println("cNo : "+dto.getcNo());
			
			String sql = "delete from interest where id = ? and cNo = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setInt(2, dto.getcNo());
			result = ps.executeUpdate();
			
			System.out.println("delete 관심사삭제 성공!");
			
			mgr.freeConnection(con, ps);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	public int insert(InterestDTO dto) {
		int result = 0;
		try {
			
			con = mgr.getConnection();
			System.out.println("id : "+dto.getId());
			System.out.println("cNo : "+dto.getcNo());
			
			String sql = "insert into interest values ( ?, ? )";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setInt(2, dto.getcNo());
			result = ps.executeUpdate();
			
			System.out.println("insert 관심사등록 성공!");
			
			mgr.freeConnection(con, ps);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
