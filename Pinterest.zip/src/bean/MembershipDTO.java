package bean;

import java.sql.Timestamp;

public class MembershipDTO {

	private String id;
	private int period;
	private Timestamp paidDate;
	private Timestamp expiredDate;
	private Timestamp sendDate;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public Timestamp getPaidDate() {
		return paidDate;
	}
	public void setPaidDate(Timestamp paidDate) {
		this.paidDate = paidDate;
	}
	public Timestamp getExpiredDate() {
		return expiredDate;
	}
	public void setExpiredDate(Timestamp expiredDate) {
		this.expiredDate = expiredDate;
	}
	public Timestamp getSendDate() {
		return sendDate;
	}
	public void setSendDate(Timestamp sendDate) {
		this.sendDate = sendDate;
	}
	
	@Override
	public String toString() {
		return "MembershipDTO [id=" + id + ", period=" + period + ", paidDate=" + paidDate + ", expiredDate="
				+ expiredDate + ", sendDate=" + sendDate + "]";
	}
	
	
	
}
