package bean;

public class ImageDTO{
	private int iNo;
	private int cNo;
	private String imgUrl;
	
	public int getiNo() {
		return iNo;
	}
	public void setiNo(int iNo) {
		this.iNo = iNo;
	}
	public int getcNo() {
		return cNo;
	}
	public void setcNo(int cNo) {
		this.cNo = cNo;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	
	@Override
	public String toString() {
		return "imageDTO [iNo=" + iNo + ", cNo=" + cNo + ", imgUrl=" + imgUrl + "]";
	}
	
	
}
