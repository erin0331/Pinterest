package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class CategoryDAO {
	Connection con;
	DBConnectionMgr mgr;

	public CategoryDAO() {
		mgr = DBConnectionMgr.getInstance();

	}

	public ArrayList<CategoryDTO> selectAll() {
		ArrayList<CategoryDTO> list = new ArrayList<>();
		try {
			con = mgr.getConnection();
			
			String sql = "select * from category";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				CategoryDTO dto = new CategoryDTO();
				dto.setcNo(rs.getInt(1));
				dto.setTitle(rs.getString(2));
				dto.setcImg(rs.getString(3));
				
				list.add(dto);
				
			}
			System.out.println("selectAll 카테고리 성공!");
			mgr.freeConnection(con, ps, rs);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
}
