package bean;

public class CommentDTO {
	private int iNo;
	private String nickName;
	private String comment;
	private String date;
	
	
	public int getiNo() {
		return iNo;
	}
	public void setiNo(int iNo) {
		this.iNo = iNo;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
	@Override
	public String toString() {
		return "CommentDTO [iNo=" + iNo + ", nickName=" + nickName + ", comment=" + comment + ", date=" + date + "]";
	}
	
	
	
	
	
	
}
