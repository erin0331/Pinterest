package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class MemberDAO {
	
	Connection con;
	DBConnectionMgr mgr;

	public MemberDAO() {
		mgr = DBConnectionMgr.getInstance();

	}
	public int checkPw(MemberDTO dto) {
		int result = 0;
		try {

			con = mgr.getConnection();

			String sql = "select id from member where id = ? and pw = ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getPw());
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				result = 1;

			}
			System.out.println("id&pw 체크 성공!");
			
			mgr.freeConnection(con, ps, rs);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;

	}
	public int changeMe(MemberDTO dto) {
		int result = 0;
		try {
			
			con = mgr.getConnection();
			
			String sql = "update member set pw = ?, nickName = ? where id = ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getPw());
			ps.setString(2, dto.getNickName());
			ps.setString(3, dto.getId());
			result =  ps.executeUpdate();
			
			System.out.println("정보수정 성공!");
			
			mgr.freeConnection(con, ps);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
	}
}
