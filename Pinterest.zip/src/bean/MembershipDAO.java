package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class MembershipDAO {
	
	Connection con;
	DBConnectionMgr mgr;

	public MembershipDAO() {
		mgr = DBConnectionMgr.getInstance();

	}
	//id로 가입 된 membership 정보를 가져옴(이용기간 유효할 때)
	public MembershipDTO selectOne(String id) {
		MembershipDTO dto2 = new MembershipDTO();

		try {

			con = mgr.getConnection();

			String sql = "select id,period,paidDate,expiredDate from membership where id = ? "
					+ "and date_format(expiredDate, '%Y-%m-%d') >= date_format(now(), '%Y-%m-%d')";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				dto2.setId(rs.getString(1));
				dto2.setPeriod(rs.getInt(2));
				dto2.setPaidDate(rs.getTimestamp(3));
				dto2.setExpiredDate(rs.getTimestamp(4));
			}
			System.out.println("멤버쉽 여부 조회성공!");
			
			mgr.freeConnection(con, ps, rs);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return dto2;

	}
	//id로 멤버쉽 가입여부 및 기간 만료/유효 여부 추출
	public int selectHow(String id) {
		int result = 0;
		
		try {
			
			con = mgr.getConnection();
			
			String sql = "select case when(expiredDate <now()) then '만료' else '유효' end as 'how'  from membership \r\n" + 
					" where id= ?;";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			
			//해당 id가 가입이력이 있을 경우 로직 실행
			while (rs.next()) {
				String how = rs.getString(1);
				//how가 만료이면 result = 1
				if (how.equals("만료")) {
					result = 1;
				}else { //how가 유효이면 result = 2
					result = 2;
				} //값이 없으면(가입이력x) result = 0
			}
			System.out.println("멤버쉽 가입 및 유효기간 여부 조회 결과 : "+ result);
			
			mgr.freeConnection(con, ps, rs);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
	}
	//오늘날짜 기준 멤버쉽이 만료되지 않은 모든 id리스트 추출
	public ArrayList<String> selectAllId() {
		ArrayList<String> list = new ArrayList<String>();

		try {

			con = mgr.getConnection();

			String sql = "select id from membership where date_format(expiredDate, '%Y-%m-%d') >= date_format(now(), '%Y-%m-%d')";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				list.add(rs.getString(1));
			}
			System.out.println("메일 서비스 대상 추출 완료!!");
			for (String id : list) {
				System.out.println("대상 id : " + id);
			}
			
			mgr.freeConnection(con, ps, rs);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}
	//멤버쉽 정보 신규 등록
	public int insert(MembershipDTO dto) {
		int result = 0;
		try {
			
			con = mgr.getConnection();
			
			String sql = "insert into membership values ( ?, ?, now(), date_add(now(),INTERVAL ? DAY), now() )";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setInt(2, dto.getPeriod());
			ps.setInt(3, dto.getPeriod());
			result = ps.executeUpdate();
			
			System.out.println("멤버쉽 등록 성공!");
			
			mgr.freeConnection(con, ps);
	} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	//결제기간 갱신의 경우 (과거 가입했지만 유효기간 만료)
	public int updateRenew(MembershipDTO dto) {
		int result = 0;
		try {
			
			con = mgr.getConnection();
			
			String sql = "update membership set period = ? , paidDate = now(), \r\n" + 
					"				expiredDate = date_add(now(),INTERVAL ? DAY), sendDate = now()\r\n" + 
					"				where id = ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, dto.getPeriod());
			ps.setInt(2, dto.getPeriod());
			ps.setString(3, dto.getId());
			result = ps.executeUpdate();
			
			System.out.println("멤버쉽 갱신(신규update) 완료!!");
			
			mgr.freeConnection(con, ps);
		} catch (Exception e) {
				// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
		

	//결제기간 연장의 경우 (유효기간 남았는데 결제)
	public int updateExtend(MembershipDTO dto) {
		int result = 0;
		try {
			
			con = mgr.getConnection();
			
			String sql = "update membership set period = period + ? , expiredDate = date_add(expiredDate,INTERVAL ? DAY)\r\n" + 
					"				where id = ? ;";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, dto.getPeriod());
			ps.setInt(2, dto.getPeriod());
			ps.setString(3, dto.getId());
			result = ps.executeUpdate();
			
			System.out.println("멤버쉽 연장(일부update) 완료!");
			
			mgr.freeConnection(con, ps);
	} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}


	//메일 발송 이후 sendDate에 업데이트
	public int updateSendDate(String id, String sendDate) {
		int result = 0;
		try {
			
			con = mgr.getConnection();
			
			String sql = "update membership set sendDate = ? where id = ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, sendDate);
			ps.setString(2, id);
			result = ps.executeUpdate();
			
			System.out.println("메일발송 날짜 업데이트 성공!");
			
			mgr.freeConnection(con, ps);
	} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
