package bean;

public class MovieDTO {
	private int rank;
	private String title;
	private double grade;
	
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getGrade() {
		return grade;
	}
	public void setGrade(double grade) {
		this.grade = grade;
	}
	
	@Override
	public String toString() {
		return "MovieDTO [rank=" + rank + ", title=" + title + ", grade=" + grade + "]";
	}
	
	
	
}
