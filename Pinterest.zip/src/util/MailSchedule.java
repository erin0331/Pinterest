package util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.mail.MessagingException;
import javax.mail.Transport;

import bean.MailDTO;
import bean.MembershipDAO;
import bean.PinDAO;
import bean.PinDTO;

public class MailSchedule{
	Date date = null;
	SimpleDateFormat df = null;
	String today = null; //해당 날짜를 yyyy-mm-dd String으로 변환 한 것
	ArrayList<MailDTO> mailList = null;
	MembershipDAO mDAO = null;
	
	//메일 보낼 시간을 세팅. 돌아오는 날 00시로 날짜 세팅 
	public MailSchedule() throws Exception {
		
		//오늘 날짜를 구해서 날짜를 +1일 해준 후, 시간을 00시로 맞추어줌
		df = new SimpleDateFormat("yyyy-MM-dd");
		date = new Date();
		date.setDate(date.getDate()+1); //하루+1
		today = df.format(date); //이때, today는 생성자 만든 날짜+1일
		String time =" 00:00:00";
		
		//메일을 보낼 실제 날짜 및 시간
		date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(today+time);
		
		Timer t = new Timer();
		t.scheduleAtFixedRate(doSend(), date, 86400000); //30분
		
	} 
	//정해진 시간에 따라 실제 메일발송을 호출 하는 메소드(쓰레드)
	public TimerTask doSend () {
		TimerTask task = new TimerTask() {
			
			@Override
			public void run() {
				try {
					
					//사람별로 메일(id,제목,내용)객체 만듬
					makeMail();
					
					//메일 전송용 객체 생성
					SendMail mail = new SendMail();
					
					//메일 객체 수만큼 돌면서 메일을 전송
					for (MailDTO dto : mailList) {
						
						//메일 전송용 메소드 실행(메일주소, 메일제목, 메일내용)
						mail.setMsg(dto);
						System.out.println(dto.getId()+ "의 메일발송 성공");
						//id 별 최근 메일 보낸 날짜 update
						mDAO.updateSendDate(dto.getId(),today);//이 때 today는 메일 발송시점
						
					}
					
				// date.setDate(date.getDate()+1); // mail발송 후 date 하루 증가 시켜줌
				}  catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		return task;
	}
	
	public void makeMail() throws  Exception {
		//각 사람별로 보낼 메일을 객체에 담아 list로 만듬
		 mailList = new ArrayList<MailDTO>();
		
		//멤버쉽에 가입된 총 id리스트를 불러옴(mail 발송할 리스트)
		mDAO = new MembershipDAO();
		ArrayList<String> idList = mDAO.selectAllId();

		Date date2 = new Date();
		//메일 발송 날짜를 포맷 변환하여 변수 저장
		today = df.format(date2); // 이 때 today는 메일 발송 시점
		
		//멤버쉽에 가입된 각 id를 각 각 수행
		for (String id : idList) {
			
			//각 id에 대해 메일 보낼 추천 image 리스트를 가져옴
			PinDAO pDao = new PinDAO();
			ArrayList<PinDTO> list = pDao.makeMail(id);
			//메일 제목 세팅 :[날짜 추천] + id(메일)님 이미지를 확인해보세요. 세팅
			String title = "["+today+" 추천] "+id+"님 이미지를 확인해보세요!";
			//메일 내용 세팅1 : 기본 html + 타이틀 + 테이블 태그 열어줌
			String content = "<html>\r\n" + 
					"<head>\r\n" + 
					"<meta charset=\"UTF-8\">\r\n" + 
					"</head>\r\n" + 
					"<body>\r\n" + 
					"<h1>추천이미지 리스트 입니다.</h1>\r\n" + 
					"	<table>\r\n" + 
					"		<tr>";
			
			//메일 내용 세팅2 : 테이블에 내용으로 이미지+url을 세팅
			for (int i = 0; i < list.size(); i++) {
				//메일 내용 세팅3 : 5개 뜬 이후에는 행이 바뀌도록 tr세팅
				if (i%4 ==0) {
					content = content + "<tr/><tr>";
				}
				PinDTO dto = list.get(i);
				content = content + "<td><img src='"+dto.getImgUrl()+"'width='300px' height='300px'>"
						+ "<br><a href='"+dto.getImgUrl()+"'>이미지 크게보기</a><br></td>";
				
			}
			//메일 내용 세팅4 : 테이블+html 태그 닫아줌
			content = content+"</tr></table></body></html>";
			//메일 객체를 만들어 id(메일주소), title, content를 세팅
			MailDTO dto = new MailDTO();
			dto.setId(id);
			dto.setTitle(title);
			dto.setContent(content);
			//한 id의 메일 객체를 list에 담음
			mailList.add(dto);
		}//for문끝
	}
	
	
}
