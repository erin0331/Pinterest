package util;

import java.util.Properties;

import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import bean.MailDTO;

public class SendMail {
	Properties p = new Properties();
	
	//properties 세팅하는 생성자
	public SendMail()  {
		//smtp관련 정보를 담을 객체 생성
		p.put("mail.smtp.host","smtp.naver.com"); //네이버 SMTP
		p.put("mail.smtp.port", "465");
		p.put("mail.smtp.starttls.enable", "true");
		p.put("mail.smtp.auth", "true");
		p.put("mail.smtp.debug", "true");
		p.put("mail.smtp.socketFactory.port", "465");
		p.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		p.put("mail.smtp.socketFactory.fallback", "false");

	}

	public void setMsg(MailDTO dto) throws Exception{
		Authenticator auth = new SMTPAuthenticator();
		Session ses = Session.getInstance(p, auth);
		//메일의 내용을 담을 객체
		MimeMessage msg = new MimeMessage(ses);
		msg.setSubject(dto.getTitle()); //제목
		
		//메일 보내는 사람
		Address fromAddr = new InternetAddress("pin_monitor@naver.com","핀 관리자");
		msg.setFrom(fromAddr);
		
		//메일 받는 사람
		Address toAddr = new InternetAddress(dto.getId());
		msg.addRecipient(Message.RecipientType.TO, toAddr);
		
		//내용과 인코딩
		
		msg.setContent(dto.getContent(), "text/html;charset=UTF-8");
		ses.setDebug(false);
		
		Transport.send(msg);
	}
}
