package member;

import java.sql.*;
import java.util.*;

public class MemberDAO {

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	String jdbc_driver = "com.mysql.jdbc.Driver";
	String jdbc_url = "jdbc:mysql://localhost:3708/pin?characterEncoding=utf8&serverTimezone=UTC";
	String id = "root";
	String pwd = "1234";
	
		 //DB연결 해제
		 void disconnect() {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		//DB연결
		void connect() {
			try {
				Class.forName(jdbc_driver);
				conn = DriverManager.getConnection(jdbc_url, id, pwd);
				System.out.println("db연결 성공");
			} catch (Exception e) {
				System.out.println("연결 오류");
				e.printStackTrace();
			}
		}	
		//회원가입
		public boolean addMember(MemberDTO dto) {
			connect();
			
			String sql = "insert into pin(id, pw, nicName) values(?,?,?)";
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, dto.getId());
				pstmt.setString(2, dto.getPw());
				pstmt.setString(3, dto.getNicName());
			
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
			finally {
				disconnect();
			}
			return true;
		}
		//로그인
		public boolean login(String id, String pw) {
			connect();
			
			String sql = "select id, pw from pin where id = ?";
			boolean result = false;
			
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				rs = pstmt.executeQuery();
				rs.next();
				if(rs.getString("pw").equals(pw))
					result=true;
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
			finally {
				disconnect();
			}
			return result;						
	}			
}
