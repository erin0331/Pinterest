package member;

public class MemberDTO {
	// 멤버변수 선언
	private String id; //아이디
	private String pw; //비밀번호
	private String nicName; //활동이름
	
	public String getId() {
		return id;
	}
	public String getPw() {
		return pw;
	}
	public String getNicName() {
		return nicName;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public void setNicName(String nicName) {
		this.nicName = nicName;
	}
	
	@Override
	public String toString() {
		return "MemberDTO [id=" + id + ", pw=" + pw + ", nicName=" + nicName + "]";
	}
	
	
	
}
